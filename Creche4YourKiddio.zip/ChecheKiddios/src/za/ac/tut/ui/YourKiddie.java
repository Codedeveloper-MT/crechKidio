package za.ac.tut.ui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;

public class YourKiddie extends JFrame implements ActionListener {

    private JLabel lblName;
    private JLabel lblGender;

    private JPanel pnlMenu;
    private JPanel pnlName;
    private JPanel pnlTextArea;
    private JPanel pnlRadiobtns;
    private JPanel pnlButtons;

    private JTextField tfName;

    private JRadioButton rdbtnMale;
    private JRadioButton rdbtnFemale;

    private JButton btnRegister;
    private JButton btnDisplay;

    private JTextArea taDisplay;
    private JScrollPane spDisplay;

    private ArrayList<Child> kidList;

    public YourKiddie() {
        kidList = new ArrayList<>();

        pnlMenu = new JPanel(new GridBagLayout());
        pnlName = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlRadiobtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlTextArea = new JPanel(new FlowLayout());

        GridBagConstraints setLayout = new GridBagConstraints();
        setLayout.insets = new java.awt.Insets(10, 10, 10, 10);
        setLayout.fill = GridBagConstraints.HORIZONTAL;

        lblName = new JLabel("Name:");
        tfName = new JTextField();
        tfName.setPreferredSize(new Dimension(250, 40));
        pnlName.add(lblName);
        pnlName.add(tfName);

        setLayout.gridx = 0;
        setLayout.gridy = 0;
        setLayout.gridwidth = 2;
        setLayout.weightx = 1;
        pnlMenu.add(pnlName, setLayout);

        lblGender = new JLabel("Gender:");
        rdbtnMale = new JRadioButton("Male");
        rdbtnFemale = new JRadioButton("Female");
        lblGender.setPreferredSize(new Dimension(100, 40));
        rdbtnMale.setPreferredSize(new Dimension(100, 50));
        rdbtnFemale.setPreferredSize(new Dimension(100, 50));
        ButtonGroup group = new ButtonGroup();
        group.add(rdbtnMale);
        group.add(rdbtnFemale);
        pnlRadiobtns.add(lblGender);
        pnlRadiobtns.add(rdbtnMale);
        pnlRadiobtns.add(rdbtnFemale);

        setLayout.gridx = 0;
        setLayout.gridy = 1;
        pnlMenu.add(pnlRadiobtns, setLayout);

        btnRegister = new JButton("Register kiddio");
        btnDisplay = new JButton("Display kiddio");
        pnlButtons.add(btnRegister);
        pnlButtons.add(btnDisplay);
        btnDisplay.setPreferredSize(new Dimension(200, 50));
        btnRegister.setPreferredSize(new Dimension(200, 50));
        btnDisplay.addActionListener(this);
        btnRegister.addActionListener(this);

        setLayout.gridx = 0;
        setLayout.gridy = 2;
        pnlMenu.add(pnlButtons, setLayout);

        taDisplay = new JTextArea(20, 40);
        taDisplay.setBackground(Color.WHITE);
        taDisplay.setPreferredSize(new Dimension(500, 400));
        taDisplay.setEditable(false);
        taDisplay.setLineWrap(true);
        taDisplay.setWrapStyleWord(true);

        spDisplay = new JScrollPane(taDisplay,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        setLayout.gridx = 0;
        setLayout.gridy = 3;
        setLayout.gridwidth = 2;
        setLayout.weightx = 1;
        setLayout.weighty = 1;
        setLayout.fill = GridBagConstraints.BOTH;
        pnlMenu.add(spDisplay, setLayout);

        this.setVisible(true);
        this.setTitle("Creche 4 Your Kiddie");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(600, 650);
        this.setContentPane(pnlMenu);
        this.pack();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRegister) {
            registerKiddie();
        } else if (e.getSource() == btnDisplay) {
            displayKiddie();
        }
    }

    private void registerKiddie() {
        if (tfName.getText().isEmpty() || (!rdbtnMale.isSelected() && !rdbtnFemale.isSelected())) {
            JOptionPane.showMessageDialog(null, "Enter Missing Information!");
        } else {
            String gender;
            if (rdbtnMale.isSelected()) {
                gender = "Male";
            } else {
                gender = "Female";
            }

            String name = tfName.getText();
            Child child = new Child(name, gender);
            kidList.add(child);

            tfName.setText("");
            rdbtnMale.setSelected(false);
            rdbtnFemale.setSelected(false);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("kiddie_info.txt", true))) {
                writer.write(child.toString());
                writer.newLine();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Cannot write to a file: " + e.getMessage());
            }
        }
    }

    private void displayKiddie() {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("kiddie_info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading from file: " + e.getMessage());
        }
        taDisplay.setText(content.toString());
    }
}
