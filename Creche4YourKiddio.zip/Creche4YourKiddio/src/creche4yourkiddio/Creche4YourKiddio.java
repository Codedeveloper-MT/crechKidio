
package creche4yourkiddio;

import za.ac.tut.ui.YourKiddie;

public class Creche4YourKiddio {

    public static void main(String[] args) {
        // TODO code application logic here\
        new YourKiddie();
    }
    
}
